import { BlackPawn, BlackPiece } from "./BlackPiece.js";
import { GameBoard } from "./Board.js";
import PlayerControl from "./PlayerController.js";
import { WhitePawn, WhitePiece } from "./WhitePiece.js";
import { WhitePieceFactory, BlackPieceFactory } from "./PieceFactory.js";
import { Pieces } from "./Board.js";

class Game {
  private static _instance: Game | undefined;
  public map: GameBoard;
  public blackPiecesOnTheBoard: BlackPiece[] = [];
  public whitePiecesOnTheBoard: WhitePiece[] = [];
  public playerControl: PlayerControl;
  public isPlayerBlack: boolean;
  public roomId: string;

  public static get instance(): Game {
    if (Game._instance === undefined) {
      Game._instance = new Game();
    }
    return Game._instance;
  }

  public start(isPlayerBlack: boolean, roomId: string): void {
    this.isPlayerBlack = isPlayerBlack;
    this.roomId = roomId;
    this.map = new GameBoard(isPlayerBlack);
    this.map.playGame();
    this.drawAll();
    this.playerControl = new PlayerControl();
  }

  public drawAll() {
    for (let i = 0; i < this.blackPiecesOnTheBoard.length; i++) {
      this.blackPiecesOnTheBoard[i].draw();
    }
    for (let i = 0; i < this.whitePiecesOnTheBoard.length; i++) {
      this.whitePiecesOnTheBoard[i].draw();
    }
  }

  public noMoreEnPassant() {
    for (let i = 0; i < this.whitePiecesOnTheBoard.length; i++) {
      if (this.whitePiecesOnTheBoard[i] instanceof WhitePawn) {
        this.whitePiecesOnTheBoard[i].enPassantAvailable = false;
      }
    }
    for (let i = 0; i < this.blackPiecesOnTheBoard.length; i++) {
      if (this.blackPiecesOnTheBoard[i] instanceof BlackPawn) {
        this.blackPiecesOnTheBoard[i].enPassantAvailable = false;
      }
    }
  }

  public updateLocalGameState(data: any) {
    try {
      // Update pieces on the board
      this.blackPiecesOnTheBoard = data.blackPieces.map((pieceData: any) => BlackPieceFactory.make(pieceData.pieceType as Pieces, pieceData.x, pieceData.y));
      this.whitePiecesOnTheBoard = data.whitePieces.map((pieceData: any) => WhitePieceFactory.make(pieceData.pieceType as Pieces, pieceData.x, pieceData.y));
    
      // Update game map
      this.map.gameMap = data.map;
    
      // Toggle turn
      this.playerControl.isMyTurn = !data.isPlayerBlackTurn;
    
      // Redraw the board
      this.map.drawMap();
      this.drawAll();
    } catch (error) {
      console.error("Error updating local game state:", error);
    }
  }
}

export { Game };
