// import app from "./config.js"; // Ensure this path is correct
// import GameClient from "./GameClient.js";

// const gameClient = GameClient.instance;

// // Check if the user is already logged in
// gameClient.onAuthStateChanged((user) => {
//   if (user) {
//     window.location.href = "menu.html";
//   }
// });
