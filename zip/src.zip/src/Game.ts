import { BlackPiece, BlackPawn } from "./BlackPiece.js";
import { GameBoard } from "./Board.js";
import PlayerControl from "./PlayerController.js";
import { WhitePiece, WhitePawn } from "./WhitePiece.js";
import { WhitePieceFactory, BlackPieceFactory } from "./PieceFactory.js";
import { Pieces } from "./Board.js";

class Game {
  private static _instance: Game | undefined;
  public map: GameBoard;
  public blackPiecesOnTheBoard: BlackPiece[] = [];
  public whitePiecesOnTheBoard: WhitePiece[] = [];
  public playerControl: PlayerControl;
  public isPlayerBlack: boolean;
  public roomId: string;

  readonly BLACK_GRID: string[][] = [
    ["R", "N", "B", "K", "Q", "B", "N", "R"],
    ["P", "P", "P", "P", "P", "P", "P", "P"],
    ["0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0"],
    ["p", "p", "p", "p", "p", "p", "p", "p"],
    ["r", "n", "b", "k", "q", "b", "n", "r"],
  ];

  readonly WHITE_GRID: string[][] = [
    ["r", "n", "b", "q", "k", "b", "n", "r"],
    ["p", "p", "p", "p", "p", "p", "p", "p"],
    ["0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0"],
    ["0", "0", "0", "0", "0", "0", "0", "0"],
    ["P", "P", "P", "P", "P", "P", "P", "P"],
    ["R", "N", "B", "Q", "K", "B", "N", "R"],
  ];

  public static get instance(): Game {
    if (Game._instance === undefined) {
      Game._instance = new Game();
    }
    return Game._instance;
  }

  public start(isPlayerBlack: boolean, roomId: string): void {
    this.isPlayerBlack = isPlayerBlack;
    this.roomId = roomId;
    this.map = new GameBoard(isPlayerBlack);
    this.map.playGame();
    this.drawAll();
    this.playerControl = new PlayerControl();
  }

  public drawAll() {
    for (let i = 0; i < this.blackPiecesOnTheBoard.length; i++) {
      this.blackPiecesOnTheBoard[i].draw();
    }
    for (let i = 0; i < this.whitePiecesOnTheBoard.length; i++) {
      this.whitePiecesOnTheBoard[i].draw();
    }
  }

  public noMoreEnPassant() {
    for (let i = 0; i < this.whitePiecesOnTheBoard.length; i++) {
      if (this.whitePiecesOnTheBoard[i] instanceof WhitePawn) {
        this.whitePiecesOnTheBoard[i].enPassantAvailable = false;
      }
    }
    for (let i = 0; i < this.blackPiecesOnTheBoard.length; i++) {
      if (this.blackPiecesOnTheBoard[i] instanceof BlackPawn) {
        this.blackPiecesOnTheBoard[i].enPassantAvailable = false;
      }
    }
  }

  public updateLocalGameState(data: any) {
    try {
      console.log("Received data for updating local game state:", data);

      if (!data || !data.blackPieces || !data.whitePieces || !data.map) {
        throw new Error("Invalid data format");
      }

      // Update pieces on the board
      this.blackPiecesOnTheBoard = data.blackPieces.map((pieceData: any) => {
        console.log("Processing black piece data:", pieceData);
        const newY = 630 - pieceData.y;
        return BlackPieceFactory.make(pieceData.pieceType as Pieces, pieceData.x, newY, pieceData.firstMove);
      });

      this.whitePiecesOnTheBoard = data.whitePieces.map((pieceData: any) => {
        console.log("Processing white piece data:", pieceData);
        const newY = 630 - pieceData.y;
        return WhitePieceFactory.make(pieceData.pieceType as Pieces, pieceData.x, newY, pieceData.firstMove);
      });

      // Reverse the map based on player's color
      if (this.isPlayerBlack) {
        this.map.gameMap = data.map.reverse().map((row: string[]) => row.reverse());
      } else {
        this.map.gameMap = data.map;
      }

      // Toggle turn
      this.playerControl.isMyTurn = !data.isPlayerBlackTurn;

      // Redraw the board
      this.map.drawMap();
      this.drawAll();
    } catch (error) {
      console.error("Error updating local game state:", error);
    }
  }
}

export { Game };
